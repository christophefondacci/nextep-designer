
rename table `HIBERNATE_UNIQUE_KEY` to `hibernate_unique_key`;



