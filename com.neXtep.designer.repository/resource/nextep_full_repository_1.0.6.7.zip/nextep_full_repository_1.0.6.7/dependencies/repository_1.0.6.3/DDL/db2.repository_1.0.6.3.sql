ECHO Altering table 'REP_VERSIONS'...;
ALTER TABLE "REP_VERSIONS" 
          ALTER COLUMN "CDATE" SET DATA TYPE TIMESTAMP
          ALTER COLUMN "UDATE" SET DATA TYPE TIMESTAMP;

ECHO Re-organizing table 'REP_VERSIONS'...;
call sysproc.admin_cmd('reorg table REP_VERSIONS');

ECHO Altering table 'REP_VERSION_REFERENCES'...;
ALTER TABLE "REP_VERSION_REFERENCES" 
          ALTER COLUMN "CDATE" SET DATA TYPE TIMESTAMP;

ECHO Re-organizing table 'REP_VERSION_REFERENCES'...;
call sysproc.admin_cmd('reorg table REP_VERSION_REFERENCES');


