ECHO Updating Oracle unique keys physical properties;
UPDATE dbom_oracle_ukeys k
	SET k.phys_id = (
		SELECT p.phys_id
		FROM dbom_uk_physicals p 
		WHERE p.key_id = k.key_id
	  )
WHERE k.phys_id IS NULL
;

ECHO Updating tables partitions physical properties;
UPDATE dbom_tab_partitions tp
	SET tp.tpart_phys_id = (
		SELECT pp.phys_id
		FROM dbom_tab_part_physicals pp
		WHERE pp.tpart_id = tp.tpart_id
	  )
;

ECHO Updating indexes partitions physical properties;
UPDATE dbom_ind_partitions ip
	SET ip.ipart_phys_id = (
		SELECT pp.phys_id
		FROM dbom_ind_part_physicals pp
		WHERE pp.ipart_id = ip.ipart_id
	  )
;
