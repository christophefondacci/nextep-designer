-- Updating Oracle unique keys physical properties
UPDATE dbom_oracle_ukeys
  SET dbom_oracle_ukeys.phys_id = (
      SELECT p.phys_id
      FROM dbom_uk_physicals p 
      WHERE p.key_id = dbom_oracle_ukeys.key_id
    )
WHERE dbom_oracle_ukeys.phys_id IS NULL
;

-- Updating tables partitions physical properties
UPDATE dbom_tab_partitions
  SET dbom_tab_partitions.tpart_phys_id = (
      SELECT pp.phys_id
      FROM dbom_tab_part_physicals pp
      WHERE pp.tpart_id = dbom_tab_partitions.tpart_id
    )
;

-- Updating indexes partitions physical properties
UPDATE dbom_ind_partitions
  SET dbom_ind_partitions.ipart_phys_id = (
      SELECT pp.phys_id
      FROM dbom_ind_part_physicals pp
      WHERE pp.ipart_id = dbom_ind_partitions.ipart_id
    )
;

-- Dropping index 'ICOL_REF_FK'...
DROP INDEX ICOL_REF_FK ON DBGM_INDEX_COLUMNS;

-- Altering table 'DBGM_INDEX_COLUMNS'...
ALTER TABLE DBGM_INDEX_COLUMNS ALTER COLUMN COL_REFID BIGINT NOT NULL;

-- Creating index 'ICOL_REF_FK'...
CREATE INDEX ICOL_REF_FK ON DBGM_INDEX_COLUMNS (
     COL_REFID
);

