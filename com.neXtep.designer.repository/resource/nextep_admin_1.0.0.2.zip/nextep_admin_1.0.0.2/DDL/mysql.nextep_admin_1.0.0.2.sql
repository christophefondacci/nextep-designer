-- Altering table 'NADM_INSTALLED_RELEASES'...
ALTER TABLE `NADM_INSTALLED_RELEASES`
           MODIFY COLUMN `CDATE` DATETIME NOT NULL COMMENT 'Installation date'
;
-- Altering table 'NADM_MODULES'...
ALTER TABLE `NADM_MODULES`
           MODIFY COLUMN `CDATE` DATETIME NOT NULL COMMENT 'Date of creation (= first install date)'
          ,MODIFY COLUMN `UDATE` DATETIME NOT NULL COMMENT 'Date of last update (= last version upgrade date)'
;
-- Altering table 'NADM_RELEASE_LOGS'...
ALTER TABLE `NADM_RELEASE_LOGS`
           MODIFY COLUMN `CDATE` DATETIME NOT NULL
;

