ECHO Altering table 'NADM_INSTALLED_RELEASES'...;
ALTER TABLE "NADM_INSTALLED_RELEASES" 
          ALTER COLUMN "CDATE" SET DATA TYPE TIMESTAMP;

ECHO Re-organizing table 'NADM_INSTALLED_RELEASES'...;
call sysproc.admin_cmd('reorg table NADM_INSTALLED_RELEASES');

ECHO Altering table 'NADM_MODULES'...;
ALTER TABLE "NADM_MODULES" 
          ALTER COLUMN "CDATE" SET DATA TYPE TIMESTAMP
          ALTER COLUMN "UDATE" SET DATA TYPE TIMESTAMP;

ECHO Re-organizing table 'NADM_MODULES'...;
call sysproc.admin_cmd('reorg table NADM_MODULES');

ECHO Altering table 'NADM_RELEASE_LOGS'...;
ALTER TABLE "NADM_RELEASE_LOGS" 
          ALTER COLUMN "CDATE" SET DATA TYPE TIMESTAMP;

ECHO Re-organizing table 'NADM_RELEASE_LOGS'...;
call sysproc.admin_cmd('reorg table NADM_RELEASE_LOGS');


