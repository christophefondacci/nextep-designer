
Prompt Creating table 'DBGM_DOMAINS'
CREATE TABLE DBGM_DOMAINS ( 
           DOM_ID BIGINT
          ,DOM_NAME VARCHAR(60)
          ,DESCRIPTION VARCHAR(300)
)
;

Prompt Creating table 'DBGM_DOMAIN_TYPES'
CREATE TABLE DBGM_DOMAIN_TYPES ( 
           DTYP_ID BIGINT
          ,DOM_ID BIGINT
          ,VENDOR VARCHAR(200)
          ,DATATYPE_NAME VARCHAR(200)
          ,DATA_LENGTH DECIMAL(19)
          ,DATA_PRECISION INTEGER(10)
)
;

Prompt Creating Primary Key constraint 'DOM_PK' on table 'DBGM_DOMAINS'
ALTER TABLE DBGM_DOMAINS ADD CONSTRAINT DOM_PK 
 PRIMARY KEY 
      (DOM_ID)
;

Prompt Creating Primary Key constraint 'DTYP_PK' on table 'DBGM_DOMAIN_TYPES'
ALTER TABLE DBGM_DOMAIN_TYPES ADD CONSTRAINT DTYP_PK 
 PRIMARY KEY 
      (DTYP_ID)
;
Prompt Creating index 'DTYP_DOM_FK'...
CREATE INDEX DTYP_DOM_FK ON DBGM_DOMAIN_TYPES (
     DOM_ID
)
;

Prompt Creating Foreign Key constraint 'DTYP_DOM_FK' on table 'DBGM_DOMAIN_TYPES'
ALTER TABLE DBGM_DOMAIN_TYPES ADD CONSTRAINT DTYP_DOM_FK 
 FOREIGN KEY 
      (DOM_ID) REFERENCES DBGM_DOMAINS
      (DOM_ID)
;

