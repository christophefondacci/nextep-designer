insert into HIBERNATE_UNIQUE_KEY(NEXT_HI) values (10050);
