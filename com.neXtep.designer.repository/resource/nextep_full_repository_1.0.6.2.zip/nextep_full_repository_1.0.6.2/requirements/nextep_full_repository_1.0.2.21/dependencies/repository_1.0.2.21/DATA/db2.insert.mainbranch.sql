insert into REP_BRANCHES(BRANCH_ID,BRANCH_NAME,DESCRIPTION) values (1,'MAIN','Main top branch');
