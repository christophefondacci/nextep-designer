insert into REP_VERSION_VIEWS(VIEW_ID,VIEW_NAME,DESCRIPTION,DBVENDOR) values (1,'neXtep System view','neXtep system view','ORACLE');
