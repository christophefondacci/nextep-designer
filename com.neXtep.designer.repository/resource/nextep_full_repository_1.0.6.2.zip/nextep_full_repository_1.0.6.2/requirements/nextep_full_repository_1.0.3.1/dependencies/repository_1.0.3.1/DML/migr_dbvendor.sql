
drop table tmp_migr;
create table tmp_migr (version_id integer, dbvendor varchar(20));

update REP_MODULES set dbvendor='ORACLE'
where version_id in (
	select c.version_id from REP_VIEW_CONTENTS c, REP_VERSION_VIEWS v
	where c.VIEW_ID=v.VIEW_ID and v.DBVENDOR='ORACLE'
);
insert into tmp_migr(version_id,dbvendor) 
select ov.version_id, 'ORACLE' from REP_MODULES m, REP_VERSIONS mv, REP_VERSIONS ov
where m.DBVENDOR='ORACLE' and mv.VERSION_ID=m.VERSION_ID and ov.VREF_ID=mv.VREF_ID
;
update REP_MODULES set dbvendor='MYSQL'
where version_id in (
	select c.version_id from REP_VIEW_CONTENTS c, REP_VERSION_VIEWS v
	where c.VIEW_ID=v.VIEW_ID and v.DBVENDOR='MYSQL'
);
insert into tmp_migr (version_id,dbvendor)
select ov.version_id, 'MYSQL' from REP_MODULES m, REP_VERSIONS mv, REP_VERSIONS ov
where m.DBVENDOR='MYSQL' and mv.VERSION_ID=m.VERSION_ID and ov.VREF_ID=mv.VREF_ID
;
update REP_MODULES set dbvendor='POSTGRE'
where version_id in (
	select c.version_id from REP_VIEW_CONTENTS c, REP_VERSION_VIEWS v
	where c.VIEW_ID=v.VIEW_ID and v.DBVENDOR='POSTGRE'
);
insert into tmp_migr (version_id,dbvendor)
select ov.version_id, 'POSTGRE' from REP_MODULES m, REP_VERSIONS mv, REP_VERSIONS ov
where m.DBVENDOR='POSTGRE' and mv.VERSION_ID=m.VERSION_ID and ov.VREF_ID=mv.VREF_ID
;

update REP_MODULES set dbvendor='ORACLE'
where version_id in (select version_id from tmp_migr where dbvendor='ORACLE')
;
update REP_MODULES set dbvendor='POSTGRE'
where version_id in (select version_id from tmp_migr where dbvendor='POSTGRE')
;
update REP_MODULES set dbvendor='MYSQL'
where version_id in (select version_id from tmp_migr where dbvendor='MYSQL')
;

drop table tmp_migr;
