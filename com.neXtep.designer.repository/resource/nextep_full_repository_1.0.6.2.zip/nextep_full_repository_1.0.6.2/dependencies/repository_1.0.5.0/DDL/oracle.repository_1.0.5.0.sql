Prompt Dropping index 'VERSION_VREF_FK'...
DROP INDEX VERSION_VREF_FK
/
Prompt Altering table 'REP_VERSIONS'
ALTER TABLE REP_VERSIONS
   ADD    (
           VERSION_TAG NUMBER
   )
/
Prompt Creating index 'VERSION_VREF_FK'...
CREATE INDEX VERSION_VREF_FK ON REP_VERSIONS (
     VREF_ID
    ,VERSION_TAG
) 
/

