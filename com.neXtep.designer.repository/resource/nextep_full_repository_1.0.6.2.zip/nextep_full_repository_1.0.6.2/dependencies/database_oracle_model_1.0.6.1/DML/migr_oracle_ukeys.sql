
update DBOM_ORACLE_UKEYS set phys_id=(
  select tp.phys_id from DBOM_UK_PHYSICALS tp 
  where tp.KEY_ID=KEY_ID
);  
