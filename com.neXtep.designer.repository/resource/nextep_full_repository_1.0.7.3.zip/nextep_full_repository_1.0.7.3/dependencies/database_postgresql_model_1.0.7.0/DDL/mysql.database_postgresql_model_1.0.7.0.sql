
-- Creating table 'DBPM_TABLES_INHERITANCES'
CREATE TABLE `DBPM_TABLES_INHERITANCES` ( 
           `TAB_VERSION_ID` BIGINT NOT NULL COMMENT 'Unique ID of the PostgreSql table'
          ,`INHERITED_TABLE_REFID` BIGINT NOT NULL
)
 COMMENT 'Definition of table inheritances'
;
-- Creating Primary Key constraint 'PGTI_PK' on table 'DBPM_TABLES_INHERITANCES'...
ALTER TABLE `DBPM_TABLES_INHERITANCES` ADD 
   CONSTRAINT PRIMARY KEY
      (`TAB_VERSION_ID`
      ,`INHERITED_TABLE_REFID`);

