ECHO Altering table 'DBGM_TABLE_COLUMNS'...;
-- Compatibility statement for repository databases with a pagesize of 8K
ALTER TABLE "DBGM_TABLE_COLUMNS" 
          ALTER COLUMN "DEFAULT_EXPR" SET DATA TYPE VARCHAR(3400);
-- Standard statement for repository databases with a pagesize of 16K or 32K
ALTER TABLE "DBGM_TABLE_COLUMNS" 
          ALTER COLUMN "DEFAULT_EXPR" SET DATA TYPE VARCHAR(4000);

ECHO Re-organizing table 'DBGM_TABLE_COLUMNS'...;
call sysproc.admin_cmd('reorg table DBGM_TABLE_COLUMNS');


