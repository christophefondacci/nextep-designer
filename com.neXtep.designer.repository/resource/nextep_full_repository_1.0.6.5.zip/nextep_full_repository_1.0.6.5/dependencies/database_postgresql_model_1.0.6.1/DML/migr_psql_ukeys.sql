
insert into DBPM_UNIQUE_KEYS (KEY_ID) 
select distinct k.KEY_ID from DBGM_UNIQUE_KEYS uk, DBGM_KEYS k, DBPM_TABLES t
where k.KEY_ID=uk.KEY_ID and t.TAB_VERSION_ID=k.TAB_VERSION_ID
;

