update DBOM_ORACLE_UKEYS ouk set phys_id=tp.phys_id 
  from DBOM_UK_PHYSICALS tp 
  where tp.KEY_ID=ouk.KEY_ID
;  
