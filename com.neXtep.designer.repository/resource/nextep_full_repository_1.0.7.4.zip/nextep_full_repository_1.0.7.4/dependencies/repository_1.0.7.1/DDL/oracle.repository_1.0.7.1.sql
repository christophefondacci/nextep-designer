PROMPT Altering table 'REP_MODULES'...
ALTER TABLE REP_MODULES
   ADD    (
           SCHEMA_NAME VARCHAR2(128)
   )
/
COMMENT ON COLUMN REP_MODULES.SCHEMA_NAME IS 'Schema name used as prefix for objects names'
/


