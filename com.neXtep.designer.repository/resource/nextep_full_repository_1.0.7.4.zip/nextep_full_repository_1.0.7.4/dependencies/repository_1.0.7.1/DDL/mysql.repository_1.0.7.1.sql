-- Altering table 'REP_MODULES'...
ALTER TABLE `REP_MODULES`
           ADD COLUMN `SCHEMA_NAME` VARCHAR(128) COMMENT 'Schema name used as prefix for objects names'
;

