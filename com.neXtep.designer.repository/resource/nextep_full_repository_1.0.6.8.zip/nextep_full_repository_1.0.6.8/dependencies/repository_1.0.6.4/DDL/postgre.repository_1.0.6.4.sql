
ALTER TABLE "HIBERNATE_UNIQUE_KEY" RENAME TO "hibernate_unique_key"
;

