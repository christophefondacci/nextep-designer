ECHO Dropping constraint 'ICOF_PK'...;
ALTER TABLE "DBOM_INDEX_COLFUNCS" DROP CONSTRAINT "ICOF_PK";

ECHO Altering table 'DBOM_INDEX_COLFUNCS'...;
ALTER TABLE "DBOM_INDEX_COLFUNCS" 
          ALTER COLUMN "COL_REFID" SET NOT NULL;

ECHO Re-organizing table 'DBOM_INDEX_COLFUNCS'...;
call sysproc.admin_cmd('reorg table DBOM_INDEX_COLFUNCS');

ECHO Creating Primary Key constraint 'ICOF_PK' on table 'DBOM_INDEX_COLFUNCS';
ALTER TABLE "DBOM_INDEX_COLFUNCS" ADD CONSTRAINT "ICOF_PK" 
 PRIMARY KEY 
      ("IND_VERSION_ID"
      ,"COL_REFID")
;


